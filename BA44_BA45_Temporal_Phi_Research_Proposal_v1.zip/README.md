# BA44 / BA45 — Temporal φ-Organization Hypothesis

## Website v1 – Research Proposal Edition

Die Website enthält:
- BA44/BA45-Hypothese
- 7,6-Hz- und φⁿ-Kontext
- 1,242705 s als ausdrücklich zu testenden Kandidaten
- experimentellen Aufbau
- wissenschaftlichen Status
- verifizierte Lacy-2026-Referenz
- Research Proposal mit Vorhersagen
- Falsifikationskriterien
- methodische Hinweise gegen nachträgliche Parameteroptimierung
- zentrale Projektgrafik unter `assets/ba44-ba45-hypothese.svg`

### Wissenschaftliche Abgrenzung

Lacy (2026) berichtet eine φⁿ-Organisation neuronaler Oszillationen mit f₀ ≈ 7,6 Hz. Die vorliegende Website erweitert diese Idee als eigenständigen Vorschlag auf eine anatomisch/funktionell spezifizierte Fragestellung zu BA44/BA45. 1,242705 s wird nicht als Lacy-Ergebnis dargestellt.

Vor Veröffentlichung sollten eigene Autoren-/Kontaktangaben, ggf. ORCID, Lizenz und Impressum ergänzt werden.
